const cssNameSpace = 'ripple';
const duration = 600;
const background = 'currentColor';
// const background = '#ccc';
const zIndex = 1;
const isDisabled = false;

export default{
    cssNameSpace,
    background,
    duration,
    zIndex,
    isDisabled,
};