<template>
  
</template>
<script>
export default {
    name: 'GoodsList',

    props: {
        dataSource: {
            required: true
        }
    },

    data() {
        return {

        };
    },

    mounted() {

    },

    methods: {


    },

    components: {}
}
</script>
<style scoped lang="scss">
@import '../../scss/theme.scss';
</style>
