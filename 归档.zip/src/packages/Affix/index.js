import AAffix from './Affix';

/* istanbul ignore next */
// Affix.install = function(Vue) {
//   Vue.component(Affix.name, Affix);
// };
export default AAffix;