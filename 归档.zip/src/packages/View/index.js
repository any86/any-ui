import AView from './AView';
export default AView;