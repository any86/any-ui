import Icon from './Icon';

Icon.install = function(Vue) {
  Vue.component(Icon.name, Icon);
};

export Icon;
