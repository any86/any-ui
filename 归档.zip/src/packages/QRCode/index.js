import AQRCode from './QRCode.vue';
export default AQRCode;