import AWarning from './AWarning';
export default AWarning;