import APicker from './Picker.vue';
export default APicker;