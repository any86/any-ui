import ALoading from './Loading.vue';
export default ALoading;