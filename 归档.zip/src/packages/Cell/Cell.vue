<template>
    <!-- 当连接用 -->
    <router-link v-if="undefined != to" v-on="$listeners" :to="to" tag="div" class="component-cell" :class="{'component-cell-border': border}">
        <span>
            <slot></slot>
        </span>
        <i v-if="-1<arrow" class="atom-icon" value="more" :style="{transform: `rotate(${arrow}deg)`}"></i>
    </router-link>

    <!-- 一般情况 -->
    <div v-else v-on="$listeners" class="component-cell" :class="{'component-cell-border': border}">
        <span>
            <slot></slot>
        </span>
        <i v-if="-1<arrow" class="atom-icon" value="more" :style="{transform: `rotate(${arrow}deg)`}"></i>
    </div>
</template>
<script>
export default {
    name: 'Cell',

    props: {
        to: {
            type: Object
        },

        arrow: {
            default: -1
        },

        border: {
            type: Boolean,
            default: true
        }
    },
}
</script>
<style scoped lang="scss">
@import '../../scss/theme.scss';
.component-cell {
    display: flex;
    background: $background;
    padding: 0 $gutter;
    min-height: 1rem;

    >span {
        flex: 1;
        position: relative;
        align-self: center; // font-size: $big;
        color: $darkest; // margin-right: $gutter;
    }
    >.atom-icon {
        align-self: center; 
        background: url(../../assets/more.svg) center center;
        background-size: 100%;
        width: 30px;
        height: 30px;
        display: inline-block;
        margin-right: -$gutter;
        transition: transform 200ms;
    }

    &-border {
        border-bottom: 1px solid $lightest;
    }




    .has-ripple {
        position: relative;
        overflow: hidden;
        -webkit-transform: translate3d(0, 0, 0);
        -o-transform: translate3d(0, 0, 0);
        transform: translate3d(0, 0, 0);
    }
    .ripple {
        display: block;
        position: absolute;
        pointer-events: none;
        border-radius: 50%;

        -webkit-transform: scale(0);
        -o-transform: scale(0);
        transform: scale(0);

        background: #fff;
        opacity: 1;
    }
    .ripple-animate {
        -webkit-animation: ripple;
        -o-animation: ripple;
        animation: ripple;
    }
    @-webkit-keyframes ripple {
        100% {
            opacity: 0;
            -webkit-transform: scale(2);
            transform: scale(2);
        }
    }
    @-o-keyframes ripple {
        100% {
            opacity: 0;
            -o-transform: scale(2);
            transform: scale(2);
        }
    }
    @keyframes ripple {
        100% {
            opacity: 0;
            transform: scale(2);
        }
    }
}
</style>
