import ASwitch from './Switch.vue';
export default ASwitch;