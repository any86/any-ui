import AMask from './Mask.vue';
export default AMask;