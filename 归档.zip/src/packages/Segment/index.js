import ASegment from './Segment.vue';
import ASegmentItem from './SegmentItem.vue';
export {ASegment, ASegmentItem};