import ALazyLoad from './LazyLoad.vue';
export default ALazyLoad;