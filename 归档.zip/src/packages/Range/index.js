import ARange from './Range.vue';
export default ARange;