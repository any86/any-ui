import ARate from './Rate';
export default ARate;