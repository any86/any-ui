import ABreadcrumb from './Breadcrumb.vue'
export default ABreadcrumb