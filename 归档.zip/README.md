# vue-atom-ui
> 玩积木一样玩组件

### 版本
1.0.832

### 演示
[预览地址](https://383514580.github.io/atom)

### 在手机上看
![image](https://user-images.githubusercontent.com/8264787/34904356-3395a8d2-f87f-11e7-85f4-7ae1a94fc587.png)


### 待解决
1. 对scss整体架构重构.
2. 做一个doc官网
3. 优化组件, 重点virtualscroll/carousel组件
4. 需要js做一个全局的z-index管理
5. 兼容fastClick
