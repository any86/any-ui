<template>
    <div @touchstart="touchStart" @touchmove="touchMove" @touchend="touchEnd" class="atom-carousel">
        <div ref="body" :style="{transform: `translate3d(${translateX}px, 0, 0)`, transitionDuration: `${transitionDuration}ms`}" @transitionEnd="transitionEnd" @webkitTransitionEnd="transitionEnd" class="atom-carousel__body">
            <slot></slot>
        </div>
        <h3>{{activeIndex}}</h3>
    </div>
</template>

<script>
import { getHeight, getWidth } from '@/utils/dom';
import throttle from 'lodash/throttle';
import times from 'lodash/times';

export default {
    name: 'Carousel',

    // provide: {
    //     perView: 1
    // },

    props: {
        value: {
            default: 0
        },

        slidesPerView: {
            type: [Number, String],
            default: 1
        },

        isLoop: {
            type: Boolean,
            default: true
        },

        spaceBetween: {
            type: [Number, String],
            default: 0
        },

        threshold: {
            type: Number,
            default: 0
        },

        autoplay: {
            type: [Object, Boolean],
            default: () => ({
                delay: 1000
            })
        },

        speed: {
            type: Number,
            default: 300
        }
    },

    data: () => ({
        count: 0,
        indexCounter: 0,
        warpWidth: 0,
        activeIndex: 0,
        isAnimating: false,
        startPointX: 0,
        transitionDuration: 0,
        translateX: 0,
        startTranslateX: 0,
        hasPaging: true,
        orderMatrix: [],
        timer: null,
        afterSliderTransitonend: () => {},
        isItemAllMounted: false
    }),

    created() {
        // this.slideTo(this.value, 0);
        // this.orderMatrix = this.calcMatrix(3);
    },

    beforeMount() {},

    mounted() {
        this.warpWidth = getWidth(this.$el);
        // 构造loop所需dom结构
        // 因为用了order控制顺序了, 就不用insertBefore了
        if (this.isLoop) {
            const headFakeNode = this.$children[this.$children.length - 1].$el.cloneNode(true);
            const lastFakeNode = this.$children[0].$el.cloneNode(true);
            headFakeNode.style.order = -1;
            lastFakeNode.style.order = this.count;
            this.$refs.body.appendChild(headFakeNode);
            this.$refs.body.appendChild(lastFakeNode);
        }
        this.slideTo(this.value, 0);
    },

    methods: {
        touchStart(e) {
            e.stopPropagation();
            // e.preventDefault();
            const point = e.touches ? e.touches[0] : e;
            this.startPointX = point.pageX;
            this.startTranslateX = this.translateX;
            this.transitionDuration = 0;
        },

        touchMove(e) {
            e.stopPropagation();
            e.preventDefault();
            // if(this.isAnimating) return;
            const point = e.touches ? e.touches[0] : e;
            const deltaX = point.pageX - this.startPointX;
            const absDeltaX = Math.abs(deltaX);
    
            // 边界自动复位
            // if (this.isLoop) {
            //     if (this.count <= this.activeIndex) {
            //         // 正翻, 超过count代表已经到达尾部的fake
            //         this.slideTo(0, 0);
            //     } else if (0 > this.activeIndex) {
            //         // 回翻,
            //         this.slideTo(this.count - 1, 0);
            //     }
            // }

            // 超过阈值开始滑动
            if (this.threshold < absDeltaX) {
                if (0 < deltaX) {
                    // 向右拖拽0->-1 / 3->2->1
                    this.translateX = this.startTranslateX + deltaX - this.threshold;
                } else {
                    // 向左拖拽
                    this.translateX = this.startTranslateX + deltaX + this.threshold;
                }
            }
        },

        touchEnd(e) {
            const point = e.changedTouches ? e.changedTouches[0] : e;
            const deltaX = point.pageX - this.startPointX;
            const absDeltaX = Math.abs(deltaX);
            // 判断边界
            if (this.maxTranslateX >= this.translateX && this.minTranslateX <= this.translateX) {
                // next / prev
                // if (15 < absDeltaX) {
                    this.activeIndex -= absDeltaX / deltaX;
                // }
            }
this.transitionDuration = 3000;
this.translateX = -1242;
            // this.slideTo(this.activeIndex);
        },

        slideTo(index, duration = this.speed, callback = () => {}) {
            this.isAnimating = 0 < duration && true;
            this.transitionDuration = duration;
            // this.activeIndex = index;
            this.translateX = ((this.isLoop ? -1 : 0) - index) * this.warpWidth;
            // this.afterSliderTransitonend = callback;
        },

        // transitionEnd() {
        //     this.isAnimating = false;
        //     this.transitionDuration = 0;
        //     // this.startTranslateX = this.translateX;
        //     this.afterSliderTransitonend(this.activeIndex);
        // }
    },

    watch: {
        value(value) {
            // if (this.count > value && -1 < value) {
            // this.slideTo(value);
            // }
        },

        activeIndex(activeIndex) {
            // this.slideTo(activeIndex);
        }
    },

    computed: {
        maxTranslateX() {
            return 0;
        },

        minTranslateX() {
            return 0 - (this.count - (this.isLoop ? -1 : 1)) * this.warpWidth;
        },

        maxStep() {
            return this.warpWidth / this.slidesPerView;
        },

        lastIndex() {
            return this.count - 1;
        }
    },

    components: {}
};
</script>
<style scoped lang=scss>
@import '../../scss/theme.scss';
$height: 0.5rem;
.atom-carousel {
    position: relative;
    width: 100%;
    overflow: hidden;

    &__body {
        position: relative;
        display: flex;
        flex-wrap: nowrap;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        transition-duration: 0ms;

        >>>.atom-carousel-item {
            position: relative;
            width: 100%;
            height: 100%;
            flex-shrink: 0;
            transition-duration: 1000ms;
            transition-property: transform;
            transition-timing-function: ease-in-out;
        }
    }

    &__paging {
        position: absolute;
        bottom: 15px;
        left: 0;
        text-align: center;
        width: 100%;
        > .paging__button {
            display: inline-block;
            margin: 0 4px;
            height: 8px;
            width: 8px;
            border-radius: 8px;
            background: rgba($dark, 0.6);
            /* transition: all $duration; */
            &--active {
                width: 16px;
                /* transform: scale(1.2); */
                background: rgba($base, 0.7);
            }
        }
    }

    &__overlay {
        position: absolute;
        z-index: 1986;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
    }
}
</style>
