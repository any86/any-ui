<template>
    <div @touchstart="touchStart" @touchmove="touchMove" @touchend="touchEnd" class="atom-carousel">
        <div ref="body" :style="{transform: `translate3d(${translateX}px, 0, 0)`, transitionDuration: `${transitionDuration}ms`}" @transitionEnd="transitionEnd" @webkitTransitionEnd="transitionEnd" class="atom-carousel__body">
            <div v-if="isLoop" :style="{order: orderMatrix[0]}" class="atom-carousel-item"></div>
            <slot></slot>
            <div v-if="isLoop" :style="{order: orderMatrix[count + 1]}" class="atom-carousel-item"></div>
        </div>
        <h2>orderMatrix: {{orderMatrix}}</h2>
        <h2>activeIndex: {{activeIndex}}</h2>
        <h2>translateX: {{translateX}}</h2>
        <h2>activeIndexWillBe: {{activeIndexWillBe}}</h2>
        <h2>deltaX: {{deltaX}}</h2>
    </div>
</template>

<script>
import { getHeight, getWidth } from '@/utils/dom';
import throttle from 'lodash/throttle';
import times from 'lodash/times';

export default {
    name: 'Carousel',

    // provide: {
    //     perView: 1
    // },

    props: {
        value: {
            default: 0
        },

        slidesPerView: {
            type: [Number, String],
            default: 1
        },

        isLoop: {
            type: Boolean,
            default: true
        },

        spaceBetween: {
            type: [Number, String],
            default: 0
        },

        threshold: {
            type: Number,
            default: 30
        },

        autoplay: {
            type: [Object, Boolean],
            default: () => ({
                delay: 1000
            })
        },

        speed: {
            type: Number,
            default: 300
        }
    },

    data: () => ({
        count: 0,
        indexCounter: 0,
        warpWidth: 0,
        activeIndex: 0,
        isAnimating: false,
        startPointX: 0,
        transitionDuration: 0,
        translateX: 0,
        startTranslateX: 0,
        hasPaging: true,

        timer: null,
        afterSliderTransitonend: () => {},
        deltaX: 0
    }),

    created() {
        // this.slideTo(this.value, 0);
        // this.orderMatrix = this.calcMatrix(3);
    },

    mounted() {
        this.warpWidth = getWidth(this.$el);
        this.slideTo(this.value, 0);
        // this.orderMatrix = this.calcMatrix(this.count);
        // if (this.isLoop) {
        //     this.playLoopSlider();
        // } else {
        //     this.playSlider();
        // }
    },

    methods: {
        playSlider() {
            this.timer = setInterval(() => {
                this.activeIndex++;
                if (this.count <= this.activeIndex) {
                    this.activeIndex = 0;
                    // this.orderMatrix = this.calcMatrix(this.count, this.last, 0);
                }
                this.slideTo(this.activeIndex, this.speed);
            }, this.autoplay.delay);
        },

        playLoopSlider() {
            this.timer = setInterval(() => {
                this.activeIndex++;
                if (this.count === this.activeIndex) {
                    // 到达尾部fake的第一页;
                    this.slideTo(this.activeIndex, this.speed, activeIndex => {
                        this.slideTo(0, 0);
                    });
                } else if (-1 === this.activeIndex) {
                    this.slideTo(this.activeIndex, this.speed, activeIndex => {
                        // 暂时走不到这个流程
                        // 因为只是正向播放
                        // 后期如果加入反向播放, 还需要在其他部分加入代码
                        this.slideTo(this.count - 1, 0);
                    });
                } else {
                    this.slideTo(this.activeIndex, this.speed);
                }
            }, this.autoplay.delay);
        },

        /**
         * @argument {Number} translateX
         * @returns {Int} activeIndex
         * */
        calcActiveIndex(translateX) {
            if (this.isLoop) {
                let activeIndex = translateX / this.warpWidth;
                return activeIndex;
            }
        },

        /**
         * 获取动画过程中的body的实时的translateX
         */
        getTranslateX() {
            // https://github.com/nolimits4web/Swiper/blob/master/src/utils/utils.js
            // 写的兼容性不完整, 后期修改参考swiper.js的getTranslate
            const style = getComputedStyle(this.$refs.body, null);
            const matrix = style.transform.split(',');
            return Math.round(matrix[4]);
        },

        touchStart(e) {
            e.stopPropagation();
            // e.preventDefault();
            const point = e.touches ? e.touches[0] : e;
            this.startPointX = point.pageX;
            this.startTranslateX = this.translateX;
            this.transitionDuration = 0;
            clearInterval(this.timer);
        },

        touchMove(e) {
            e.stopPropagation();
            e.preventDefault();
            // if(this.isAnimating) return;
            const point = e.touches ? e.touches[0] : e;
            const deltaX = (this.deltaX = point.pageX - this.startPointX);
            const absDeltaX = Math.abs(deltaX);

            // if(0 > point.pageX) return;

            // 运动中发生拖拽
            // 暂停在当前translateX
            if (this.isAnimating) {
                const currentTranslateX = this.getTranslateX();
                this.startTranslateX = currentTranslateX;
                this.translateX = this.startTranslateX;
                this.isAnimating = false;
            }

            // 实时计算order矩阵

            // 在滑动发生前做些对2端faker的定位处理
            // 如果, 阈值范围内, 那么进行order交换操作
            // 反之, 拖拽超过阈值, 可以滑动
            if (this.threshold < absDeltaX) {
                // 向右拖拽情况
                if (0 < deltaX) {
                    //  交换order
                    // 如果当前第一张
                } else {
                    // 向左拖拽
                    // 交换order
                }

                this.translateX = this.startTranslateX + deltaX - absDeltaX / deltaX * this.threshold;
                this.activeIndex = Math.round(this.calcActiveIndex(-this.translateX)) - (this.isLoop ? 1 : 0);
            }
        },

        touchEnd(e) {
            const point = e.changedTouches ? e.changedTouches[0] : e;
            const deltaX = point.pageX - this.startPointX;
            const absDeltaX = Math.abs(deltaX);
            const absTranlateX = Math.abs(this.translateX);

            // 判断边界
            // if (this.maxTranslateX >= this.translateX && this.minTranslateX <= this.translateX) {
            //     // 针对isLoop做activeIndex的偏移
            //     let activeIndex = absTranlateX / this.warpWidth - 1 + (this.isLoop ? 0 : 1);
            //     if (0.1 < 0 - deltaX / absDeltaX * Math.abs(activeIndex)) {
            //         this.activeIndex = Math.ceil(activeIndex);
            //     } else {
            //         this.activeIndex = Math.floor(activeIndex);
            //     }
            // }

            this.slideTo(this.activeIndex);
        },

        slideTo(index, duration = this.speed, callback = () => {}) {
            this.isAnimating = 0 < duration && true;
            this.transitionDuration = duration;
            this.activeIndex = index;
            this.translateX = ((this.isLoop ? -1 : 0) - index) * this.warpWidth;
            this.startTranslateX = this.translateX;
            this.afterSliderTransitonend = callback;
        },

        transitionEnd() {
            this.isAnimating = false;
            this.transitionDuration = 0;
            this.afterSliderTransitonend(this.activeIndex);
        }
    },

    watch: {
        value(value) {
            // 取消自动播放
            // clearInterval(this.timer);
            // 只能返回总数范围内的
            if (this.count > this.activeIndex && -1 < this.activeIndex) {
                this.slideTo(value);
            }
        },

        activeIndex(activeIndex) {
            this.$emit('change', { realIndex: this.realIndex, activeIndex: this.activeIndex });
        },

        realIndex(realIndex) {
            this.$emit('input', realIndex);
        },
        /**
         * 主要用来控制偷偷的切换tranlateX
         * 来实现从fake的头/尾隐形切换到real的头/尾的
         */
        activeIndexWillBe(activeIndexWillBe) {
            if (this.lastIndex === activeIndexWillBe && -1 === this.activeIndex) {
                this.slideTo(this.lastIndex, 0);
            } else if (this.count + 1 === this.activeIndexWillBe) {
                this.slideTo(0, 0);
            }
        }
    },

    computed: {
        /**
         * 根据拖拽方向判断即将显示页面index
         */
        activeIndexWillBe() {
            const MathInt = 0 < this.deltaX ? Math.floor : Math.ceil;
            let activeIndexWillBe = MathInt(-this.translateX / this.warpWidth);
            if (this.isLoop) {
                activeIndexWillBe -= 1;
                if (-2 === activeIndexWillBe) {
                    activeIndexWillBe = this.lastIndex;
                } else if (this.count === activeIndexWillBe) {
                    // activeIndexWillBe = 0;
                }
            } else {
            }
            return activeIndexWillBe;
        },
        /**
         * 输入结果由activeIndexWillBe主导
         * 用来表示每个item的order的矩阵
         */
        orderMatrix() {
            // if(1 == this.count) return [0];
            let array = [];
            for (let i = -1; i <= this.count; i++) {
                array.push(i);
            }

            if (2 === this.count) {
                if (2 === this.activeIndexWillBe) {
                    array = 0 < this.deltaX ? [-1, 0, 1, 2] : [-1, 2, 1, 0];
                } else if (1 === this.activeIndexWillBe && 1 === this.activeIndex) {
                    array = 0 < this.deltaX ? [-1, 0, 1, 2] : [-1, 2, 1, 0];
                }
            } else {
                if (-1 === this.activeIndexWillBe || (0 === this.activeIndexWillBe && 0 === this.activeIndex)) {
                    // 从第一张, 进入最后一张
                    const temp = array[0];
                    array[0] = array[this.count];
                    array[this.count] = temp;
                    log('a');
                } else if (this.count === this.activeIndexWillBe || (this.lastIndex === this.activeIndexWillBe && this.lastIndex === this.activeIndex)) {
                    // 从最后一张, 进入第一张
                    const temp = array[1];
                    array[1] = array[this.count + 1];
                    array[this.count + 1] = temp;
                    log('b');
                } else if (this.count === this.activeIndex && this.lastIndex === this.activeIndexWillBe) {
                    const temp = array[1];
                    array[1] = array[this.count + 1];
                    array[this.count + 1] = temp;
                    log('c');
                } else if (-1 === this.activeIndex && 0 === this.activeIndexWillBe) {
                    const temp = array[0];
                    array[0] = array[this.count];
                    array[this.count] = temp;
                    log('d');
                }
            }

            return array;
        },

        maxTranslateX() {
            return 0;
        },

        minTranslateX() {
            return 0 - (this.count - (this.isLoop ? -1 : 1)) * this.warpWidth;
        },

        maxStep() {
            return this.warpWidth / this.slidesPerView;
        },

        lastIndex() {
            return this.count - 1;
        }
    },

    components: {}
};
</script>
<style scoped lang=scss>
@import '../../scss/theme.scss';
$height: 0.5rem;
.atom-carousel {
    position: relative;
    width: 100%;
    overflow: hidden;

    &__body {
        position: relative;
        display: flex;
        flex-wrap: nowrap;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        transition-duration: 0ms;

        >>>.atom-carousel-item {
            position: relative;
            width: 100%;
            height: 100%;
            flex-shrink: 0;
            transition-duration: 1000ms;
            transition-property: transform;
            transition-timing-function: ease-in-out;
        }
    }

    &__paging {
        position: absolute;
        bottom: 15px;
        left: 0;
        text-align: center;
        width: 100%;
        > .paging__button {
            display: inline-block;
            margin: 0 4px;
            height: 8px;
            width: 8px;
            border-radius: 8px;
            background: rgba($dark, 0.6);
            /* transition: all $duration; */
            &--active {
                width: 16px;
                /* transform: scale(1.2); */
                background: rgba($base, 0.7);
            }
        }
    }

    &__overlay {
        position: absolute;
        z-index: 1986;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
    }
}
</style>
