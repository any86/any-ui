import Vue from 'vue'
import AButton from '@/components/Button/Button.vue'

describe('Button.vue', () => {
  it('查看是否有内容', () => {
    const Constructor = Vue.extend(AButton)
    const vm = new Constructor().$mount()
    expect(vm.$el.textContent)
      .to.equal('还真有!')
  })
})
