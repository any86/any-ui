### 安装
```bash
npm i vue-atom-ui --save
```




 