### 引入
``` javascript
import Atom from 'vue-atom-ui';
```